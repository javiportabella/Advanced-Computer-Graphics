#include "shader.h"

Shader::Shader() : bgColor(Vector3D(0.0))
{ }

Shader::Shader(Vector3D bgColor_) : bgColor(bgColor_)
{ }
